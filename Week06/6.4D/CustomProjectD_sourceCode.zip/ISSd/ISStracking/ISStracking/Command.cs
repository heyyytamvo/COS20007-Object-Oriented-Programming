﻿using System;
namespace ISStracking
{
	public abstract class Command 
	{
		public Command()
		{
		}
	}
}

